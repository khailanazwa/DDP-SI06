import streamlit as st

st.title("Halaman Dashboard")
st.image("1.jpg", caption="Bangtan")

# fungsi menghitung dan menyimpan total
def total():
    total_nabung = sum(m["jumlah"]
                       for m in st.session_state["total_semua"] # st_sesssion untuk menyimpan data sementara
                       if m ["Tipe"] == "Menabung")
    
    return total_nabung


total_semua = st.session_state["total_semua"]
total_nabung = total()

st.metric("Total Menabung", f"Rp{total_nabung}")