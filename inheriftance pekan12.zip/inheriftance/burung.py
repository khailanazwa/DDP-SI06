from Animals import *

class burung(animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak,jenis_bulu, bunyi):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_bulu =jenis_bulu
        self.bunyi = bunyi
    def cetak_burung(self):
        super().cetak()
        print(f"hewan ini berbulu {self.jenis_bulu} dan hewan ini berbunyi {self.bunyi}")

print("--------------------------------------------------------------------------------------------------------------")
pipit = burung("burung pipit", "biji-bijian", "udara", "bertelur", "kuning dan hitam","wek wek wek wek wek" )
pipit.cetak_burung()

print("--------------------------------------------------------------------------------------------------------------------")
gagak = burung("burung gagak", "biji-bijian", "udara", "bertelur", "hitam","gak gak gak gak" )
gagak.cetak_burung()