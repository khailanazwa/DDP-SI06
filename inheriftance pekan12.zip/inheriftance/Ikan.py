from Animals import *

class Ikan(animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna_sisik, bunyi):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna_sisik =warna_sisik
        self.bunyi = bunyi
    def cetak_Ikan(self):
        super().cetak()
        print(f"hewan ini berwarna {self.warna_sisik} dan hewan ini berbunyi {self.bunyi}")

mujaer = Ikan("ikan mujaer", "tanmaan", "air", "bertelur", "silver dan hitam","blub blub blub" )
mujaer.cetak_Ikan()

print("----------------------------------------------------------------")
lele = Ikan("ikan lele", "daging tiren", "air", "bertelur", "hitam","blub blub blub" )
lele.cetak_Ikan()