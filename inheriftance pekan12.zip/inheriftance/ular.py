from Animals import *

class ular(animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak,warna_sisik, bunyi, jenis_racun):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna_sisik =warna_sisik
        self.bunyi = bunyi
        self.jenis_racun = jenis_racun
    def cetak_ular(self):
        super().cetak()
        print(f"hewan ini berwarna kuning {self.warna_sisik} jenis racun yang dimiliki hewan ini yaitu {self.jenis_racun} dan hewan ini berbunyi {self.bunyi}")

print("----------------------------------------------------------------------------------------------------------")
python = ular("ular python", "daging", "darat", "bertelur", "hitam", "miotoksin","shesssss" )
python.cetak_ular()

print("----------------------------------------------------------------------------------------------------------")
anaconda = ular("ular anaconda", "daging", "darat", "bertelur", "hijau","tidak berbisa", "shesssss" )
anaconda.cetak_ular()