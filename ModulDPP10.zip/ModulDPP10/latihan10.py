print("--gunakan modul--")
import Perhitungan
Perhitungan.tambah (5,2)
Perhitungan.kurang(10,3)
Perhitungan.kali (5,6)

print("--gunakan modul yang ada dengan alias--")
import Perhitungan as lt
lt.bagi (20,2)
lt.pangkat (2,3)

print("-- memanggil modul dengan seluruh fungsinya --")
from Perhitungan import *
tambah (20,30)
kurang (2,3)
kali (5,6)
bagi (20,2)
pangkat (2,3)

print("-- memanggil modul dengan sebagian fungsinya dan diganti alias --")
from Perhitungan import tambah as add, kali as x, kurang as k
add (20,30)
x (5,6)
k (2,3)
