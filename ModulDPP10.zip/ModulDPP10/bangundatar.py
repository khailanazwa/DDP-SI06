import math

def l_persegi(sisi):
    luas = sisi*sisi
    keliling = sisi*sisi*sisi*sisi
    print(f'Luas persegi {sisi} * {sisi} = {luas}')
    print(f'Keliling persegi adalah {keliling}')

def l_lingkaran(jari_jari):
    luas = math.pi * (jari_jari ** 2)
    print(f'Luas lingkaran {jari_jari} * {jari_jari} = {luas}')

def l_persegi_panjang(panjang,lebar):
    luas = panjang * lebar
    print(f'Luas persegi panjang', panjang, 'x', lebar, '=', luas)

def l_segitiga(alas,tinggi):
    luas = 0.5 * alas * tinggi
    print(f'Luas segitiga = 0.5 x {alas} x {tinggi} = {luas}')

def l_jajargenjang(alas,tinggi):
    luas = alas * tinggi
    print(f'luas jajargenjang {alas} * {tinggi} = {alas}')