import bangundatar

print('--perhitungan persegi--')
bangundatar.l_persegi(10)
bangundatar.l_lingkaran(2)
bangundatar.l_persegi_panjang(2,5)
bangundatar.l_jajargenjang(4,2)
bangundatar.l_segitiga(3,2)


import bangunruang
bangunruang.l_kubus(9)
bangunruang.l_balok(3,2,8)
bangunruang.l_prisma(4,1,5)
bangunruang.l_tabung(3.14,5,7)
bangunruang.l_kerucut(3.14,5,6,9)